/**
 * 
 */
package exe6_8;

/**
 * @author nhatthy
 *
 */
public interface IBookstore {

	/**
	 * 
	 * @param author
	 * @return
	 */
	public IBookstore thisAuthor(String author);
	
}
