/**
 * 
 */
package exe6_9;

/**
 * @author nhatthy
 *
 */
public class Mouth {
	private Location location;
	private ARiver river;
	public Mouth(Location location, ARiver river) {
		super();
		this.location = location;
		this.river = river;
	}
	
	
}
