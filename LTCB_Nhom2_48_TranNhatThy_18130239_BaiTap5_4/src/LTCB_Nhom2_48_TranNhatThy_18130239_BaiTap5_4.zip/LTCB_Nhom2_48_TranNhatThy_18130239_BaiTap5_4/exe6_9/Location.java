package exe6_9;

public class Location {
	private int x;
	private int y;
	private String name;
	/**
	 * 
	 * @param x
	 * @param y
	 * @param name
	 */
	public Location(int x, int y, String name) {
		super();
		this.x = x;
		this.y = y;
		this.name = name;
	}
	
}
