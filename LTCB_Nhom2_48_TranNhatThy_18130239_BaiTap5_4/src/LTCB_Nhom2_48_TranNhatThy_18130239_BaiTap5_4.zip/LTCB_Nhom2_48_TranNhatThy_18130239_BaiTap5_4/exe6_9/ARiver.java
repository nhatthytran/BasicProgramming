/**
 * 
 */
package exe6_9;

/**
 * @author nhatthy
 *
 */
public class ARiver {
	protected Location location;
	protected double length;
	/**
	 * 
	 * @param location
	 * @param length
	 */
	public ARiver(Location location, double length) {
		super();
		this.location = location;
		this.length = length;
	}
	
}
