package exe6_9;
/**
 * 
 * @author nhatthy
 *
 */
public class Source extends ARiver {

	public Source(Location location, double length) {
		super(location, length);
		// TODO Auto-generated constructor stub
	}

}
