package exe6_7;

public interface IBrand {
	
}
