/**
 * 
 */
package exe6_7;

/**
 * @author nhatthy
 *
 */
public class MTBrand implements IBrand {
	public MTBrand() {
		// TODO Auto-generated constructor stub
	}

}
